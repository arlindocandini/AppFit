from app import create_app
from app.extensions import db
from app.modules.recipes.models import Ingredient, Recipe, RecipeIngredient, IngredientCategory, DifficultyLevel
from app.modules.meal_plan.models import MealType

def run_seed():
    app = create_app()
    with app.app_context():
        # Clean existing
        RecipeIngredient.query.delete()
        Recipe.query.delete()
        Ingredient.query.delete()
        
        print("🌱 Seeding Ingredients...")
        
        ingredients_data = [
            {"name": "Peito de Frango", "cat": IngredientCategory.CARNES, "cals": 165},
            {"name": "Ovo", "cat": IngredientCategory.LATICINIOS, "cals": 143},
            {"name": "Aveia", "cat": IngredientCategory.GRAOS, "cals": 389},
            {"name": "Banana", "cat": IngredientCategory.FRUTAS, "cals": 89},
            {"name": "Brócolis", "cat": IngredientCategory.HORTIFRUTI, "cals": 34},
            {"name": "Arroz Integral", "cat": IngredientCategory.GRAOS, "cals": 112},
            {"name": "Feijão", "cat": IngredientCategory.GRAOS, "cals": 347},
            {"name": "Patáta Doce", "cat": IngredientCategory.HORTIFRUTI, "cals": 86},
            {"name": "Tomate", "cat": IngredientCategory.HORTIFRUTI, "cals": 18},
            {"name": "Azeite", "cat": IngredientCategory.CONDIMENTOS, "cals": 884},
        ]
        
        ing_dict = {}
        for row in ingredients_data:
            i = Ingredient(name=row["name"], category=row["cat"], calories_per_100g=row["cals"])
            db.session.add(i)
            ing_dict[row["name"]] = i
            
        db.session.flush()

        print("🍲 Seeding Recipes...")

        recipes_data = [
            {
                "name": "Frango Grelhado com Brócolis e Batata Doce",
                "instructions": "1. Grelhe o frango.\n2. Cozinhe o brócolis e batata no vapor.",
                "prep": 10, "cook": 20, "diff": DifficultyLevel.EASY,
                "tags": ["high_protein", "low_fat"],
                "meals": [MealType.LUNCH.value, MealType.DINNER.value],
                "ings": [
                    (ing_dict["Peito de Frango"], 150, "g"),
                    (ing_dict["Brócolis"], 100, "g"),
                    (ing_dict["Patáta Doce"], 100, "g"),
                    (ing_dict["Azeite"], 1, "tbsp")
                ]
            },
            {
                "name": "Panqueca de Banana com Aveia",
                "instructions": "1. Amasse a banana.\n2. Misture com ovo e aveia.\n3. Frite em fogo baixo.",
                "prep": 5, "cook": 5, "diff": DifficultyLevel.EASY,
                "tags": ["sweet", "breakfast"],
                "meals": [MealType.BREAKFAST.value, MealType.MORNING_SNACK.value],
                "ings": [
                    (ing_dict["Banana"], 1, "un"),
                    (ing_dict["Ovo"], 2, "un"),
                    (ing_dict["Aveia"], 30, "g")
                ]
            },
            {
                "name": "Arroz com Feijão e Frango",
                "instructions": "1. Sirva arroz, feijão e frango grelhado.",
                "prep": 5, "cook": 15, "diff": DifficultyLevel.EASY,
                "tags": ["classic", "high_protein"],
                "meals": [MealType.LUNCH.value, MealType.DINNER.value],
                "ings": [
                    (ing_dict["Arroz Integral"], 100, "g"),
                    (ing_dict["Feijão"], 80, "g"),
                    (ing_dict["Peito de Frango"], 120, "g"),
                    (ing_dict["Tomate"], 50, "g")
                ]
            }
        ]

        for r_data in recipes_data:
            r = Recipe(
                name=r_data["name"],
                instructions=r_data["instructions"],
                prep_time_min=r_data["prep"],
                cook_time_min=r_data["cook"],
                difficulty=r_data["diff"],
                tags=r_data["tags"],
                meal_types=r_data["meals"]
            )
            db.session.add(r)
            db.session.flush()
            
            for ing, qty, unit in r_data["ings"]:
                ri = RecipeIngredient(
                    recipe_id=r.id,
                    ingredient_id=ing.id,
                    quantity=qty,
                    unit=unit
                )
                db.session.add(ri)

        db.session.commit()
        print("✅ Seeding complete!")

if __name__ == "__main__":
    run_seed()
