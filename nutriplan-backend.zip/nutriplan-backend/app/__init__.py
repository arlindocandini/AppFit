import os
from flask import Flask
from .config import config_by_name
from .extensions import db, migrate, jwt, cors, celery_app


def create_app(config_name: str = None) -> Flask:
    """Application factory."""
    config_name = config_name or os.environ.get("FLASK_ENV", "development")
    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])

    # Init extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})

    # Configure Celery
    celery_app.conf.update(
        broker_url=app.config["CELERY_BROKER_URL"],
        result_backend=app.config["CELERY_RESULT_BACKEND"],
        task_serializer="json",
        result_serializer="json",
        accept_content=["json"],
        timezone="UTC",
    )

    class ContextTask(celery_app.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app.Task = ContextTask

    # Ensure upload dir exists
    os.makedirs(app.config.get("UPLOAD_FOLDER", "uploads"), exist_ok=True)

    # Register blueprints
    _register_blueprints(app)

    # Health check
    @app.get("/health")
    def health():
        return {"status": "ok", "service": "nutriplan-api"}

    return app


def _register_blueprints(app: Flask):
    from .modules.auth.routes import auth_bp
    from .modules.users.routes import users_bp
    from .modules.recipes.routes import recipes_bp
    from .modules.meal_plan.routes import meal_plan_bp
    from .modules.shopping_list.routes import shopping_list_bp
    from .modules.food_log.routes import food_log_bp
    from .modules.ai.routes import ai_bp
    from .modules.metrics.routes import metrics_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(users_bp, url_prefix="/api/profile")
    app.register_blueprint(recipes_bp, url_prefix="/api/recipes")
    app.register_blueprint(meal_plan_bp, url_prefix="/api/meal-plans")
    app.register_blueprint(shopping_list_bp, url_prefix="/api/shopping-lists")
    app.register_blueprint(food_log_bp, url_prefix="/api/food-logs")
    app.register_blueprint(ai_bp, url_prefix="/api/ai")
    app.register_blueprint(metrics_bp, url_prefix="/api/metrics")
