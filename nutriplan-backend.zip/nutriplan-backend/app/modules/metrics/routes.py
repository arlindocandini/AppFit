from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timedelta, date, timezone
from ...extensions import db
from ..users.models import UserWeightLog
from ..food_log.models import FoodLog, ExerciseLog

metrics_bp = Blueprint("metrics", __name__)


@metrics_bp.get("/dashboard")
@jwt_required()
def get_dashboard():
    """Returns overview metrics (e.g., last 7 days summary)."""
    user_id = get_jwt_identity()
    period_days = int(request.args.get("period", 7))
    
    start_date = date.today() - timedelta(days=period_days)
    
    # 1. Weight Evolution
    weight_logs = UserWeightLog.query.filter(
        UserWeightLog.user_id == user_id,
        UserWeightLog.logged_at >= start_date
    ).order_by(UserWeightLog.logged_at.asc()).all()
    
    # 2. Calories (Food + Exercise)
    foods = FoodLog.query.filter(
        FoodLog.user_id == user_id,
        FoodLog.logged_at >= start_date
    ).all()
    
    exercises = ExerciseLog.query.filter(
        ExerciseLog.user_id == user_id,
        ExerciseLog.logged_at >= start_date
    ).all()
    
    # Aggregate calories by day
    # Needs SQLite/Postgres agnostic aggregation, doing in python for simplicity in this sprint
    daily_calories = {}
    
    for i in range(period_days + 1):
        d_str = (start_date + timedelta(days=i)).isoformat()
        daily_calories[d_str] = {"eaten": 0, "burned": 0}
        
    for f in foods:
        d_str = f.logged_at.date().isoformat()
        if d_str in daily_calories:
            daily_calories[d_str]["eaten"] += f.total_calories
            
    for e in exercises:
        d_str = e.logged_at.date().isoformat()
        if d_str in daily_calories:
            daily_calories[d_str]["burned"] += e.calories_burned
            
    return jsonify({
        "weight_history": [{"date": w.logged_at.date().isoformat(), "weight": w.weight_kg} for w in weight_logs],
        "daily_calories": daily_calories
    }), 200
