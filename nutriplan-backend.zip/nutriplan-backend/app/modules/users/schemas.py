from marshmallow import Schema, fields
from marshmallow_enum import EnumField
from .models import FamilyType, CookingLevel, Goal


class UserProfileSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True)
    sex = fields.String()
    birth_date = fields.Date()
    height_cm = fields.Float()
    current_weight_kg = fields.Float()
    family_type = EnumField(FamilyType, by_value=True)
    num_people = fields.Integer()
    has_children = fields.Boolean()
    children_ages = fields.List(fields.Integer())
    medical_conditions = fields.List(fields.String())
    dietary_restrictions = fields.List(fields.String())
    cooking_level = EnumField(CookingLevel, by_value=True)
    goal = EnumField(Goal, by_value=True)
    daily_meals = fields.List(fields.String())


class UserWeightLogSchema(Schema):
    id = fields.Integer(dump_only=True)
    weight_kg = fields.Float(required=True)
    notes = fields.String(allow_none=True)
    logged_at = fields.DateTime(required=True)
