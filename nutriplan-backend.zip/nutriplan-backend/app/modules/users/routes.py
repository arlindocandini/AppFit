from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from ...extensions import db
from .models import UserProfile, UserWeightLog
from .schemas import UserProfileSchema, UserWeightLogSchema
from datetime import datetime, timezone
from .models import FamilyType, CookingLevel, Goal # Assuming these enums are defined in .models

users_bp = Blueprint("users", __name__)


@users_bp.get("/")
@jwt_required()
def get_profile():
    user_id = get_jwt_identity()
    profile = UserProfile.query.filter_by(user_id=user_id).first()
    
    if not profile:
        return jsonify({"message": "Profile not found"}), 404

    return jsonify(UserProfileSchema().dump(profile)), 200


@users_bp.put("/")
@jwt_required()
def update_profile():
    user_id = get_jwt_identity()
    profile = UserProfile.query.filter_by(user_id=user_id).first()
    
    data = request.get_json()
    
    if not profile:
        profile = UserProfile(user_id=user_id) # Use user_id from get_jwt_identity()
        db.session.add(profile)

    # Update basic info
    if 'name' in data: profile.name = data['name']
    if 'sex' in data: profile.sex = data['sex']
    if 'birth_date' in data:
        try:
             profile.birth_date = datetime.strptime(data['birth_date'], '%Y-%m-%d').date()
        except ValueError:
             return jsonify({"msg": "Invalid date format. Use YYYY-MM-DD"}), 400
    
    if 'height_cm' in data: profile.height_cm = data['height_cm']
    if 'current_weight_kg' in data: profile.current_weight_kg = data['current_weight_kg']
    if 'target_weight_kg' in data: profile.target_weight_kg = data['target_weight_kg']
    
    # Family & Lifestyle
    if 'family_type' in data: profile.family_type = FamilyType(data['family_type'])
    if 'num_people' in data: profile.num_people = data['num_people']
    if 'has_children' in data: profile.has_children = data['has_children']
    if 'medical_conditions' in data: profile.medical_conditions = data['medical_conditions']
    if 'dietary_restrictions' in data: profile.dietary_restrictions = data['dietary_restrictions']
    if 'cooking_level' in data: profile.cooking_level = CookingLevel(data['cooking_level'])
    if 'goal' in data: profile.goal = Goal(data['goal'])
    if 'daily_meals' in data: profile.daily_meals = data['daily_meals']

    db.session.commit()
    return jsonify(UserProfileSchema().dump(profile)), 200


@users_bp.get("/weight-log")
@jwt_required()
def get_weight_logs():
    user_id = get_jwt_identity()
    logs = UserWeightLog.query.filter_by(user_id=user_id).order_by(UserWeightLog.logged_at.desc()).all()
    return jsonify(UserWeightLogSchema(many=True).dump(logs)), 200


@users_bp.post("/weight-log")
@jwt_required()
def add_weight_log():
    user_id = get_jwt_identity()
    schema = UserWeightLogSchema()
    data = schema.load(request.json)
    
    log = UserWeightLog(
        user_id=user_id,
        weight_kg=data["weight_kg"],
        notes=data.get("notes"),
        logged_at=data.get("logged_at", datetime.now(timezone.utc))
    )
    
    # Update current weight on profile as well
    profile = UserProfile.query.filter_by(user_id=user_id).first()
    if profile:
        profile.current_weight_kg = log.weight_kg
        
    db.session.add(log)
    db.session.commit()
    
    return jsonify(UserWeightLogSchema().dump(log)), 201
