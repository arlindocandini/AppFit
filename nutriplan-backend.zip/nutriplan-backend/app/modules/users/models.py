import enum
from ...extensions import db
from ...shared.models.base import BaseModel


class FamilyType(str, enum.Enum):
    SINGLE = "single"
    COUPLE = "couple"
    FAMILY = "family"


class CookingLevel(str, enum.Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"


class Goal(str, enum.Enum):
    LOSE_WEIGHT = "lose_weight"
    MAINTAIN = "maintain"
    GAIN_MUSCLE = "gain_muscle"
    EAT_HEALTHIER = "eat_healthier"


class UserProfile(BaseModel):
    __tablename__ = "user_profiles"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    name = db.Column(db.String(120), nullable=False)
    sex = db.Column(db.String(10))  # male, female, other
    birth_date = db.Column(db.Date)
    height_cm = db.Column(db.Float)
    current_weight_kg = db.Column(db.Float)
    family_type = db.Column(db.Enum(FamilyType), default=FamilyType.SINGLE)
    num_people = db.Column(db.Integer, default=1)
    has_children = db.Column(db.Boolean, default=False)
    children_ages = db.Column(db.JSON, default=list)  # [3, 7, 12]
    medical_conditions = db.Column(db.JSON, default=list)  # ["diabetes", "hypertension"]
    # Preferences
    dietary_restrictions = db.Column(db.JSON, default=list) # e.g. ["vegetarian", "gluten_free", "peanut_allergy"]
    cooking_level = db.Column(db.Enum(CookingLevel), default=CookingLevel.BEGINNER)
    goal = db.Column(db.Enum(Goal), nullable=False)
    daily_meals = db.Column(db.JSON, default=lambda: ["breakfast", "lunch", "dinner"]) # Array of meal types they eat.

    # Relationships
    user = db.relationship("User", back_populates="profile")

    def __repr__(self):
        return f"<UserProfile {self.name}>"


class UserWeightLog(BaseModel):
    __tablename__ = "user_weight_logs"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    weight_kg = db.Column(db.Float, nullable=False)
    notes = db.Column(db.Text)
    logged_at = db.Column(db.DateTime(timezone=True), nullable=False)

    # Relationships
    user = db.relationship("User", back_populates="weight_logs")

    def __repr__(self):
        return f"<WeightLog {self.user_id}:{self.weight_kg}kg>"
