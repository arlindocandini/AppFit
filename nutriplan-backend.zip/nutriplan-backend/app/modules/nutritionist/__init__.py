# Stub for Nutritionist platform (V2)
from flask import Blueprint

nutritionist_bp = Blueprint("nutritionist", __name__)

# Handlers will go here
