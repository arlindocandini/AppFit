from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, date, timezone

from ...extensions import db
from .models import FoodLog, FoodLogItem, ExerciseLog
from .schemas import FoodLogSchema, ExerciseLogSchema
from ..ai.models import AIJob

food_log_bp = Blueprint("food_log", __name__)


@food_log_bp.post("/")
@jwt_required()
def add_food_log():
    """Manually add a food log or confirm items from an AI job."""
    user_id = get_jwt_identity()
    data = request.json
    
    log = FoodLog(
        user_id=user_id,
        logged_at=datetime.fromisoformat(data["logged_at"]) if "logged_at" in data else datetime.now(timezone.utc),
        meal_type=data["meal_type"],
        notes=data.get("notes"),
        ai_job_id=data.get("ai_job_id")
    )
    db.session.add(log)
    db.session.flush()
    
    for item_data in data.get("items", []):
        item = FoodLogItem(
            log_id=log.id,
            ingredient_id=item_data.get("ingredient_id"),
            name=item_data["name"],
            quantity_g=item_data["quantity_g"],
            calories=item_data.get("calories", 0)
        )
        db.session.add(item)
        
    db.session.commit()
    
    return jsonify(FoodLogSchema().dump(log)), 201


@food_log_bp.get("/today")
@jwt_required()
def get_today_logs():
    """Get all food and exercise logs for today."""
    user_id = get_jwt_identity()
    
    # Needs proper timezone handling in prod, using UTC/server time for Sprint 1
    today = date.today()
    
    food_logs = FoodLog.query.filter(
        FoodLog.user_id == user_id,
        db.func.date(FoodLog.logged_at) == today
    ).all()
    
    exercise_logs = ExerciseLog.query.filter(
        ExerciseLog.user_id == user_id,
        db.func.date(ExerciseLog.logged_at) == today
    ).all()
    
    return jsonify({
        "food_logs": FoodLogSchema(many=True).dump(food_logs),
        "exercise_logs": ExerciseLogSchema(many=True).dump(exercise_logs),
        "total_calories_eaten": sum(log.total_calories for log in food_logs),
        "total_calories_burned": sum(log.calories_burned for log in exercise_logs)
    }), 200


@food_log_bp.post("/exercise")
@jwt_required()
def add_exercise():
    user_id = get_jwt_identity()
    data = request.json
    
    log = ExerciseLog(
        user_id=user_id,
        exercise_type=data["exercise_type"],
        duration_min=data["duration_min"],
        intensity=data.get("intensity", "medium"),
        calories_burned=data.get("calories_burned", 0),
        logged_at=datetime.fromisoformat(data["logged_at"]) if "logged_at" in data else datetime.now(timezone.utc),
        notes=data.get("notes")
    )
    db.session.add(log)
    db.session.commit()
    
    return jsonify(ExerciseLogSchema().dump(log)), 201
