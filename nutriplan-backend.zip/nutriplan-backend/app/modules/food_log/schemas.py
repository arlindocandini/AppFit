from marshmallow import Schema, fields
from marshmallow_enum import EnumField
from .models import MealType
from ..recipes.schemas import IngredientSchema


class FoodLogItemSchema(Schema):
    id = fields.Integer(dump_only=True)
    ingredient_id = fields.Integer(allow_none=True)
    name = fields.String(required=True)
    quantity_g = fields.Float(required=True)
    calories = fields.Float()
    
    ingredient = fields.Nested(IngredientSchema, dump_only=True)


class FoodLogSchema(Schema):
    id = fields.Integer(dump_only=True)
    logged_at = fields.DateTime(required=True)
    meal_type = EnumField(MealType, by_value=True, required=True)
    notes = fields.String(allow_none=True)
    photo_url = fields.String(allow_none=True)
    ai_job_id = fields.String(allow_none=True)
    
    items = fields.Nested(FoodLogItemSchema, many=True)
    total_calories = fields.Float(dump_only=True)


class ExerciseLogSchema(Schema):
    id = fields.Integer(dump_only=True)
    exercise_type = fields.String(required=True)
    duration_min = fields.Integer(required=True)
    intensity = fields.String(allow_none=True)
    calories_burned = fields.Float()
    logged_at = fields.DateTime(required=True)
    notes = fields.String(allow_none=True)
