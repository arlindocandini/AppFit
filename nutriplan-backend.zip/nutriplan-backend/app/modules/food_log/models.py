from ...extensions import db
from ...shared.models.base import BaseModel
from ..meal_plan.models import MealType


class FoodLog(BaseModel):
    __tablename__ = "food_logs"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    logged_at = db.Column(db.DateTime(timezone=True), nullable=False)
    meal_type = db.Column(db.Enum(MealType), nullable=False)
    notes = db.Column(db.Text)
    photo_url = db.Column(db.String(500))
    ai_job_id = db.Column(db.String(100))  # Reference to Celery task ID

    # Relationships
    user = db.relationship("User", back_populates="food_logs")
    items = db.relationship("FoodLogItem", back_populates="food_log", cascade="all, delete-orphan")

    @property
    def total_calories(self):
        return sum(item.calories for item in self.items if item.calories)

    def __repr__(self):
        return f"<FoodLog {self.user_id} {self.meal_type} {self.logged_at}>"


class FoodLogItem(BaseModel):
    __tablename__ = "food_log_items"

    log_id = db.Column(db.Integer, db.ForeignKey("food_logs.id"), nullable=False)
    ingredient_id = db.Column(db.Integer, db.ForeignKey("ingredients.id"), nullable=True)
    name = db.Column(db.String(200), nullable=False)
    quantity_g = db.Column(db.Float, nullable=False)
    calories = db.Column(db.Float, default=0)

    # Relationships
    food_log = db.relationship("FoodLog", back_populates="items")
    ingredient = db.relationship("Ingredient")

    def __repr__(self):
        return f"<FoodLogItem {self.name} {self.calories}kcal>"


class ExerciseLog(BaseModel):
    __tablename__ = "exercise_logs"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    exercise_type = db.Column(db.String(100), nullable=False)
    duration_min = db.Column(db.Integer, nullable=False)
    intensity = db.Column(db.String(20))  # low, medium, high
    calories_burned = db.Column(db.Float, default=0)
    logged_at = db.Column(db.DateTime(timezone=True), nullable=False)
    notes = db.Column(db.Text)

    # Relationships
    user = db.relationship("User", back_populates="exercise_logs")

    def __repr__(self):
        return f"<ExerciseLog {self.user_id} {self.exercise_type} {self.calories_burned}kcal>"
