import enum
from ...extensions import db
from ...shared.models.base import BaseModel


class DifficultyLevel(str, enum.Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class IngredientCategory(str, enum.Enum):
    HORTIFRUTI = "hortifruti"
    FRUTAS = "frutas"
    LATICINIOS = "laticinios"
    CARNES = "carnes"
    PEIXES = "peixes"
    GRAOS = "graos"
    CONDIMENTOS = "condimentos"
    BEBIDAS = "bebidas"
    LIMPEZA = "limpeza"
    HIGIENE = "higiene"
    OUTROS = "outros"


class Ingredient(BaseModel):
    __tablename__ = "ingredients"

    name = db.Column(db.String(120), nullable=False)
    category = db.Column(db.Enum(IngredientCategory), nullable=False, default=IngredientCategory.OUTROS)
    calories_per_100g = db.Column(db.Float, default=0)
    carbs_g = db.Column(db.Float, default=0)
    protein_g = db.Column(db.Float, default=0)
    fat_g = db.Column(db.Float, default=0)
    fiber_g = db.Column(db.Float, default=0)
    shelf_life_fridge_days = db.Column(db.Integer)   # days in fridge
    shelf_life_freezer_days = db.Column(db.Integer)  # days in freezer
    how_to_pick_tips = db.Column(db.Text)             # how to select at supermarket

    def __repr__(self):
        return f"<Ingredient {self.name}>"


class Recipe(BaseModel):
    __tablename__ = "recipes"

    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    instructions = db.Column(db.Text, nullable=False)
    prep_time_min = db.Column(db.Integer, default=0)
    cook_time_min = db.Column(db.Integer, default=0)
    difficulty = db.Column(db.Enum(DifficultyLevel), default=DifficultyLevel.EASY)
    servings = db.Column(db.Integer, default=2)
    calories_per_serving = db.Column(db.Float, default=0)
    image_url = db.Column(db.String(500))
    tags = db.Column(db.JSON, default=list)  # ["vegetarian", "gluten_free", "low_carb"]
    meal_types = db.Column(db.JSON, default=list)  # ["breakfast", "lunch", "dinner", "snack"]
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    recipe_ingredients = db.relationship("RecipeIngredient", back_populates="recipe", cascade="all, delete-orphan")

    @property
    def total_time_min(self):
        return self.prep_time_min + self.cook_time_min

    def __repr__(self):
        return f"<Recipe {self.name}>"


class RecipeIngredient(BaseModel):
    __tablename__ = "recipe_ingredients"

    recipe_id = db.Column(db.Integer, db.ForeignKey("recipes.id"), nullable=False)
    ingredient_id = db.Column(db.Integer, db.ForeignKey("ingredients.id"), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(30), nullable=False)  # g, ml, un, tbsp, tsp, cup

    # Relationships
    recipe = db.relationship("Recipe", back_populates="recipe_ingredients")
    ingredient = db.relationship("Ingredient")

    def __repr__(self):
        return f"<RecipeIngredient {self.recipe_id}:{self.ingredient_id}>"
