from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from .models import Recipe
from .schemas import RecipeSchema

recipes_bp = Blueprint("recipes", __name__)


@recipes_bp.get("/")
@jwt_required()
def get_recipes():
    """List all available recipes with optional filters."""
    tags = request.args.get("tags")
    difficulty = request.args.get("difficulty")
    max_time = request.args.get("max_time", type=int)
    meal_type = request.args.get("meal_type")
    
    query = Recipe.query.filter_by(is_active=True)
    
    if tags:
        # Simplistic tag filtering (assuming single tag for now)
        # PostgreSQL supports better JSONB query: column.contains([tag])
        pass  # TODO: implement proper JSON tag filtering
        
    if difficulty:
        query = query.filter(Recipe.difficulty == difficulty)
        
    if max_time:
        query = query.filter((Recipe.prep_time_min + Recipe.cook_time_min) <= max_time)
        
    recipes = query.limit(50).all()
    
    # Filter by meal_type in python for now (SQLite/JSON issue in dev vs Postgres)
    if meal_type:
        recipes = [r for r in recipes if meal_type in (r.meal_types or [])]
        
    return jsonify(RecipeSchema(many=True).dump(recipes)), 200


@recipes_bp.get("/<int:recipe_id>")
@jwt_required()
def get_recipe(recipe_id):
    """Get single recipe details."""
    recipe = Recipe.query.get_or_404(recipe_id)
    return jsonify(RecipeSchema().dump(recipe)), 200
