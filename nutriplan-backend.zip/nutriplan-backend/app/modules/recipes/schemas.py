from marshmallow import Schema, fields
from marshmallow_enum import EnumField
from .models import DifficultyLevel, IngredientCategory


class IngredientSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True)
    category = EnumField(IngredientCategory, by_value=True)
    calories_per_100g = fields.Float()
    carbs_g = fields.Float()
    protein_g = fields.Float()
    fat_g = fields.Float()
    fiber_g = fields.Float()
    shelf_life_fridge_days = fields.Integer(allow_none=True)
    shelf_life_freezer_days = fields.Integer(allow_none=True)
    how_to_pick_tips = fields.String(allow_none=True)


class RecipeIngredientSchema(Schema):
    id = fields.Integer(dump_only=True)
    ingredient = fields.Nested(IngredientSchema)
    quantity = fields.Float(required=True)
    unit = fields.String(required=True)


class RecipeSchema(Schema):
    id = fields.Integer(dump_only=True)
    name = fields.String(required=True)
    description = fields.String()
    instructions = fields.String()
    prep_time_min = fields.Integer()
    cook_time_min = fields.Integer()
    total_time_min = fields.Integer(dump_only=True)
    difficulty = EnumField(DifficultyLevel, by_value=True)
    servings = fields.Integer()
    calories_per_serving = fields.Float()
    image_url = fields.String(allow_none=True)
    tags = fields.List(fields.String())
    meal_types = fields.List(fields.String())
    
    ingredients = fields.Nested(RecipeIngredientSchema, attribute="recipe_ingredients", many=True)
