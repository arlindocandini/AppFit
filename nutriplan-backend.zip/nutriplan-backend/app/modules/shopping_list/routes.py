from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy.orm import joinedload

from ...extensions import db
from .models import ShoppingList, ShoppingItem
from .schemas import ShoppingListSchema, ShoppingItemSchema
from ..meal_plan.models import MealPlan


shopping_list_bp = Blueprint("shopping_list", __name__)


@shopping_list_bp.post("/from-meal-plan/<int:plan_id>")
@jwt_required()
def generate_from_meal_plan(plan_id):
    """Generates a smart shopping list by aggregating all ingredients in a meal plan."""
    user_id = get_jwt_identity()
    plan = MealPlan.query.filter_by(id=plan_id, user_id=user_id).first_or_404()
    
    # 1. Disable existing active lists
    existing = ShoppingList.query.filter_by(user_id=user_id, is_active=True).all()
    for lst in existing:
        lst.is_active = False

    # 2. Extract and Aggregate Ingredients
    ingredients_agg = {}
    
    for slot in plan.slots:
        for ri in slot.recipe.recipe_ingredients:
            key = (ri.ingredient_id, ri.unit)
            
            if key not in ingredients_agg:
                ingredients_agg[key] = {
                    "ingredient": ri.ingredient,
                    "quantity": 0,
                    "unit": ri.unit
                }
            
            # Multiply ingredient quantity by the number of servings in the slot
            ingredients_agg[key]["quantity"] += ri.quantity * slot.servings
            
    # 3. Create the List
    s_list = ShoppingList(
        user_id=user_id,
        meal_plan_id=plan.id,
        name=f"Compras: Semana {plan.week_start_date.strftime('%d/%m')}"
    )
    db.session.add(s_list)
    db.session.flush()
    
    # 4. Create Items
    for key, data in ingredients_agg.items():
        ing = data["ingredient"]
        item = ShoppingItem(
            list_id=s_list.id,
            ingredient_id=ing.id,
            name=ing.name,
            quantity=data["quantity"],
            unit=data["unit"],
            category=ing.category
        )
        db.session.add(item)
        
    db.session.commit()
    
    return jsonify(ShoppingListSchema().dump(s_list)), 201


@shopping_list_bp.get("/<int:list_id>")
@jwt_required()
def get_list(list_id):
    """Gets a shopping list structured by sections (categories)."""
    user_id = get_jwt_identity()
    s_list = ShoppingList.query.filter_by(id=list_id, user_id=user_id).first_or_404()
    
    # Dump the list
    data = ShoppingListSchema().dump(s_list)
    
    # Group items by category for the mobile app
    grouped_items = {}
    for item in data["items"]:
        cat = item["category"]
        if cat not in grouped_items:
            grouped_items[cat] = []
        grouped_items[cat].append(item)
        
    data["items_by_category"] = grouped_items
    
    return jsonify(data), 200


@shopping_list_bp.put("/<int:list_id>/items/<int:item_id>")
@jwt_required()
def update_item(list_id, item_id):
    """Updates price, checks off, or marks if already at home."""
    user_id = get_jwt_identity()
    
    # Ensure user owns the list
    ShoppingList.query.filter_by(id=list_id, user_id=user_id).first_or_404()
    item = ShoppingItem.query.filter_by(id=item_id, list_id=list_id).first_or_404()
    
    schema = ShoppingItemSchema(partial=True)
    data = schema.load(request.json)
    
    if "price" in data:
        item.price = data["price"]
    if "is_checked" in data:
        item.is_checked = data["is_checked"]
    if "is_at_home" in data:
        item.is_at_home = data["is_at_home"]
        
    db.session.commit()
    
    return jsonify(ShoppingItemSchema().dump(item)), 200


@shopping_list_bp.get("/<int:list_id>/summary")
@jwt_required()
def get_summary(list_id):
    """Returns total spent per category."""
    user_id = get_jwt_identity()
    s_list = ShoppingList.query.filter_by(id=list_id, user_id=user_id).first_or_404()
    
    summary = {}
    for item in s_list.items:
        if item.subtotal:
            cat = item.category.value
            summary[cat] = summary.get(cat, 0) + item.subtotal
            
    summary["TOTAL"] = s_list.total_price
    
    return jsonify(summary), 200
