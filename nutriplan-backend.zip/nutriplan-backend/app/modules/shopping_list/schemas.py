from marshmallow import Schema, fields
from marshmallow_enum import EnumField
from .models import IngredientCategory


class ShoppingItemSchema(Schema):
    id = fields.Integer(dump_only=True)
    ingredient_id = fields.Integer(allow_none=True)
    name = fields.String(required=True)
    quantity = fields.Float(required=True)
    unit = fields.String()
    category = EnumField(IngredientCategory, by_value=True)
    price = fields.Float(allow_none=True)
    is_checked = fields.Boolean()
    is_at_home = fields.Boolean()
    notes = fields.String(allow_none=True)
    subtotal = fields.Float(dump_only=True)


class ShoppingListSchema(Schema):
    id = fields.Integer(dump_only=True)
    meal_plan_id = fields.Integer(allow_none=True)
    name = fields.String(required=True)
    created_at = fields.DateTime(dump_only=True)
    
    items = fields.Nested(ShoppingItemSchema, many=True)
    total_price = fields.Float(dump_only=True)
