from ...extensions import db
from ...shared.models.base import BaseModel
from ..recipes.models import IngredientCategory


class ShoppingList(BaseModel):
    __tablename__ = "shopping_lists"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    meal_plan_id = db.Column(db.Integer, db.ForeignKey("meal_plans.id"), nullable=True)
    name = db.Column(db.String(200), nullable=False, default="Lista de Compras")
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    user = db.relationship("User", back_populates="shopping_lists")
    meal_plan = db.relationship("MealPlan", back_populates="shopping_lists")
    items = db.relationship("ShoppingItem", back_populates="shopping_list", cascade="all, delete-orphan")

    @property
    def total_price(self):
        return sum(
            (item.price or 0) * item.quantity
            for item in self.items
            if item.price is not None
        )

    def __repr__(self):
        return f"<ShoppingList {self.name}>"


class ShoppingItem(BaseModel):
    __tablename__ = "shopping_items"

    list_id = db.Column(db.Integer, db.ForeignKey("shopping_lists.id"), nullable=False)
    ingredient_id = db.Column(db.Integer, db.ForeignKey("ingredients.id"), nullable=True)
    name = db.Column(db.String(200), nullable=False)
    quantity = db.Column(db.Float, nullable=False, default=1)
    unit = db.Column(db.String(30), default="un")
    category = db.Column(db.Enum(IngredientCategory), default=IngredientCategory.OUTROS)
    price = db.Column(db.Float, nullable=True)          # price per unit
    is_checked = db.Column(db.Boolean, default=False)   # checked at supermarket
    is_at_home = db.Column(db.Boolean, default=False)   # already at home, skip buying
    notes = db.Column(db.String(300))

    # Relationships
    shopping_list = db.relationship("ShoppingList", back_populates="items")
    ingredient = db.relationship("Ingredient")

    @property
    def subtotal(self):
        if self.price is None:
            return None
        return round(self.price * self.quantity, 2)

    def __repr__(self):
        return f"<ShoppingItem {self.name}>"
