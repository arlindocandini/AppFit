from marshmallow import Schema, fields, validate


class RegisterSchema(Schema):
    email = fields.Email(required=True)
    password = fields.String(required=True, validate=validate.Length(min=6))
    name = fields.String(required=True, validate=validate.Length(min=2))


class LoginSchema(Schema):
    email = fields.Email(required=True)
    password = fields.String(required=True)


class UserResponseSchema(Schema):
    id = fields.Integer()
    email = fields.Email()
    is_active = fields.Boolean()
    is_verified = fields.Boolean()
    created_at = fields.DateTime()


class TokenResponseSchema(Schema):
    access_token = fields.String()
    refresh_token = fields.String()
    user = fields.Nested(UserResponseSchema)
