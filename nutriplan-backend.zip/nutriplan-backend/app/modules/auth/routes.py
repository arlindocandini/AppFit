from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt_identity,
)
from ...extensions import db
from .models import User
from ..users.models import UserProfile
from .schemas import RegisterSchema, LoginSchema, TokenResponseSchema, UserResponseSchema


auth_bp = Blueprint("auth", __name__)


@auth_bp.post("/register")
def register():
    schema = RegisterSchema()
    data = schema.load(request.json)

    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"message": "Email already registered"}), 400

    user = User(email=data["email"])
    user.set_password(data["password"])
    
    # Create empty profile with the basic name and default options
    profile = UserProfile(name=data["name"], user=user)
    
    db.session.add(user)
    db.session.add(profile)
    db.session.commit()

    access_token = create_access_token(identity=user.id)
    refresh_token = create_refresh_token(identity=user.id)

    response_data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "user": user
    }
    
    return jsonify(TokenResponseSchema().dump(response_data)), 201


@auth_bp.post("/login")
def login():
    schema = LoginSchema()
    data = schema.load(request.json)

    user = User.query.filter_by(email=data["email"]).first()
    
    if not user or not user.check_password(data["password"]):
        return jsonify({"message": "Invalid email or password"}), 401

    if not user.is_active:
        return jsonify({"message": "Account is disabled"}), 403

    access_token = create_access_token(identity=user.id)
    refresh_token = create_refresh_token(identity=user.id)

    response_data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "user": user
    }
    
    return jsonify(TokenResponseSchema().dump(response_data)), 200


@auth_bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    access_token = create_access_token(identity=identity)
    return jsonify({"access_token": access_token}), 200


@auth_bp.get("/me")
@jwt_required()
def me():
    identity = get_jwt_identity()
    user = db.session.get(User, identity)
    if not user:
        return jsonify({"message": "User not found"}), 404
        
    return jsonify(UserResponseSchema().dump(user)), 200
