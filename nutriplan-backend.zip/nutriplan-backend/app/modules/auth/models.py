import bcrypt
from ...extensions import db
from ...shared.models.base import BaseModel


class User(BaseModel):
    __tablename__ = "users"

    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_verified = db.Column(db.Boolean, default=False, nullable=False)

    # Relationships
    profile = db.relationship("UserProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    weight_logs = db.relationship("UserWeightLog", back_populates="user", cascade="all, delete-orphan")
    meal_plans = db.relationship("MealPlan", back_populates="user", cascade="all, delete-orphan")
    shopping_lists = db.relationship("ShoppingList", back_populates="user", cascade="all, delete-orphan")
    food_logs = db.relationship("FoodLog", back_populates="user", cascade="all, delete-orphan")
    exercise_logs = db.relationship("ExerciseLog", back_populates="user", cascade="all, delete-orphan")
    ai_jobs = db.relationship("AIJob", back_populates="user", cascade="all, delete-orphan")

    def set_password(self, password: str):
        self.password_hash = bcrypt.hashpw(
            password.encode("utf-8"), bcrypt.gensalt()
        ).decode("utf-8")

    def check_password(self, password: str) -> bool:
        return bcrypt.checkpw(
            password.encode("utf-8"), self.password_hash.encode("utf-8")
        )

    def __repr__(self):
        return f"<User {self.email}>"
