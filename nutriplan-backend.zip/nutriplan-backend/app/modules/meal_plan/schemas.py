from marshmallow import Schema, fields
from marshmallow_enum import EnumField
from .models import DayOfWeek, MealType
from ..recipes.schemas import RecipeSchema


class MealPlanSlotSchema(Schema):
    id = fields.Integer(dump_only=True)
    day_of_week = EnumField(DayOfWeek, by_value=True)
    meal_type = EnumField(MealType, by_value=True)
    recipe = fields.Nested(RecipeSchema)
    servings = fields.Integer()
    warnings = fields.List(fields.String())


class MealPlanSchema(Schema):
    id = fields.Integer(dump_only=True)
    week_start_date = fields.Date(required=True)
    generated_at = fields.DateTime(dump_only=True)
    notes = fields.String(allow_none=True)
    is_active = fields.Boolean()
    
    slots = fields.Nested(MealPlanSlotSchema, many=True)
