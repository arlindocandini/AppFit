import enum
from ...extensions import db
from ...shared.models.base import BaseModel


class MealType(str, enum.Enum):
    BREAKFAST = "breakfast"
    MORNING_SNACK = "morning_snack"
    LUNCH = "lunch"
    AFTERNOON_SNACK = "afternoon_snack"
    DINNER = "dinner"
    SUPPER = "supper"


class DayOfWeek(str, enum.Enum):
    MONDAY = "monday"
    TUESDAY = "tuesday"
    WEDNESDAY = "wednesday"
    THURSDAY = "thursday"
    FRIDAY = "friday"
    SATURDAY = "saturday"
    SUNDAY = "sunday"


class MealPlan(BaseModel):
    __tablename__ = "meal_plans"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    week_start_date = db.Column(db.Date, nullable=False)
    generated_at = db.Column(db.DateTime(timezone=True))
    notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    user = db.relationship("User", back_populates="meal_plans")
    slots = db.relationship("MealPlanSlot", back_populates="meal_plan", cascade="all, delete-orphan")
    shopping_lists = db.relationship("ShoppingList", back_populates="meal_plan")

    def __repr__(self):
        return f"<MealPlan user={self.user_id} week={self.week_start_date}>"


class MealPlanSlot(BaseModel):
    __tablename__ = "meal_plan_slots"

    meal_plan_id = db.Column(db.Integer, db.ForeignKey("meal_plans.id"), nullable=False)
    day_of_week = db.Column(db.Enum(DayOfWeek), nullable=False)
    meal_type = db.Column(db.Enum(MealType), nullable=False)
    recipe_id = db.Column(db.Integer, db.ForeignKey("recipes.id"), nullable=False)
    servings = db.Column(db.Integer, default=1)
    warnings = db.Column(db.JSON, default=list) # List of alert strings if recipe conflicts with profile

    # Relationships
    meal_plan = db.relationship("MealPlan", back_populates="slots")
    recipe = db.relationship("Recipe")

    def __repr__(self):
        return f"<MealPlanSlot {self.day_of_week} {self.meal_type}>"
