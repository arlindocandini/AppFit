from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, date

from ...extensions import db
from .models import MealPlan, MealPlanSlot
from .schemas import MealPlanSchema, MealPlanSlotSchema
from .service import MealPlanService

meal_plan_bp = Blueprint("meal_plan", __name__)


@meal_plan_bp.post("/generate")
@jwt_required()
def generate_plan():
    """Generates an adaptive meal plan for the week."""
    user_id = get_jwt_identity()
    
    # Request param or default to next Monday
    data = request.json or {}
    start_date_str = data.get("week_start_date")
    
    if start_date_str:
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
    else:
        # Default to today for MVP simplicity
        start_date = date.today()

    try:
        new_plan = MealPlanService.generate_adaptative_plan(user_id, start_date)
        return jsonify(MealPlanSchema().dump(new_plan)), 201
    except ValueError as e:
        return jsonify({"message": str(e)}), 400


@meal_plan_bp.get("/current")
@jwt_required()
def get_current_plan():
    """Gets the active meal plan for the user."""
    user_id = get_jwt_identity()
    
    plan = MealPlan.query.filter_by(user_id=user_id, is_active=True).order_by(MealPlan.week_start_date.desc()).first()
    
    if not plan:
        return jsonify({"message": "No active meal plan found"}), 404
        
    return jsonify(MealPlanSchema().dump(plan)), 200


@meal_plan_bp.put("/<int:plan_id>/slots/<int:slot_id>")
@jwt_required()
def update_slot(plan_id, slot_id):
    """Swaps a recipe in a specific slot (i.e., user didn't like the suggestion)."""
    user_id = get_jwt_identity()
    
    plan = MealPlan.query.filter_by(id=plan_id, user_id=user_id).first_or_404()
    slot = MealPlanSlot.query.filter_by(id=slot_id, meal_plan_id=plan.id).first_or_404()
    
    data = request.json
    new_recipe_id = data.get("recipe_id")
    
    if not new_recipe_id:
        return jsonify({"message": "recipe_id is required"}), 400
        
    slot.recipe_id = new_recipe_id
    db.session.commit()
    
    return jsonify(MealPlanSlotSchema().dump(slot)), 200
