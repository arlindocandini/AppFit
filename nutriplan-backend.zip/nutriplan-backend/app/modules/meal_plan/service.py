from datetime import datetime, timezone
import random
from ...extensions import db
from .models import MealPlan, MealPlanSlot, DayOfWeek, MealType
from ..users.models import UserProfile
from ..recipes.models import Recipe


class MealPlanService:
    @staticmethod
    def _check_warnings(recipe: Recipe, profile: UserProfile) -> list[str]:
        """Checks for conflicts between recipe tags and user's dietary restrictions."""
        warnings = []
        user_restrictions = profile.dietary_restrictions or []
        recipe_tags = recipe.tags or []
        
        # Simple simulated check: if user is "vegetarian" and recipe isn't tagged "vegetarian"
        if "vegetarian" in user_restrictions and "vegetarian" not in recipe_tags:
            warnings.append("Receita pode conter carnes (modo alerta ativado).")

        if "gluten_free" in user_restrictions and "gluten_free" not in recipe_tags:
             warnings.append("Receita pode conter glúten.")
             
        # Add more logic based on specific ingredient matching if needed sprint 2
        return warnings

    @staticmethod
    def generate_adaptative_plan(user_id: int, week_start_date) -> MealPlan:
        """
        Gera um cardápio semanal. Ao invés de barrar receitas que fogem da restrição, 
        apenas exibe um alerta no `warnings` do slot.
        """
        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if not profile:
            raise ValueError("Perfil do usuário não encontrado")

        # Disable current active plans for this week
        existing_plans = MealPlan.query.filter_by(
            user_id=user_id, 
            is_active=True, 
            week_start_date=week_start_date
        ).all()
        for plan in existing_plans:
            plan.is_active = False

        new_plan = MealPlan(
            user_id=user_id,
            week_start_date=week_start_date,
            generated_at=datetime.now(timezone.utc),
            notes=f"Gerado para {profile.family_type.value} com objetivo {profile.goal.value}"
        )
        db.session.add(new_plan)
        db.session.flush()

        all_recipes = Recipe.query.filter_by(is_active=True).all()
        servings = profile.num_people
        
        # User defined meal routine (from onboarding)
        user_routines = profile.daily_meals or ["breakfast", "lunch", "dinner"]
        required_meals = []
        for mr in user_routines:
            try:
                required_meals.append(MealType(mr))
            except ValueError:
                pass
                
        # Basic caloric strategy
        # EAT_HEALTHIER ~ 2000, LOSE_WEIGHT ~ 1500, GAIN_MUSCLE ~ 2500
        target_calories = 2000
        if profile.goal.name == "LOSE_WEIGHT":
            target_calories = 1500
        elif profile.goal.name == "GAIN_MUSCLE":
            target_calories = 2500

        days = list(DayOfWeek)

        for day in days:
            daily_cals = 0
            for i, meal_type in enumerate(required_meals):
                suitable_recipes = [r for r in all_recipes if meal_type.value in (r.meal_types or [])]
                
                # Further filter based on remaining calories if we are on the last meal
                # Or try to pick recipes that fit the caloric distribution per meal
                # Breakfast 25%, Lunch 35%, Dinner 25%, Snacks 15% (for MVP just randomize from suitable)
                
                if not suitable_recipes:
                    suitable_recipes = all_recipes

                if suitable_recipes:
                    selected_recipe = random.choice(suitable_recipes)
                    
                    slot_warnings = MealPlanService._check_warnings(selected_recipe, profile)
                    
                    slot = MealPlanSlot(
                        meal_plan_id=new_plan.id,
                        day_of_week=day,
                        meal_type=meal_type,
                        recipe_id=selected_recipe.id,
                        servings=servings,
                        warnings=slot_warnings
                    )
                    db.session.add(slot)

        db.session.commit()
        return new_plan
