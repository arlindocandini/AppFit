from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import uuid
import datetime

from ...extensions import db
from .models import AIJob, AIJobStatus, AIJobType
from ...tasks.ai_tasks import process_food_photo

ai_bp = Blueprint("ai", __name__)


@ai_bp.post("/photo")
@jwt_required()
def analyze_photo():
    """Starts a Celery task to analyze food photo via Gemini."""
    user_id = get_jwt_identity()
    
    data = request.json
    image_base64 = data.get("image_base64")
    if not image_base64:
        return jsonify({"message": "image_base64 is required"}), 400

    job_id_uuid = str(uuid.uuid4())
    job = AIJob(
        task_id=job_id_uuid,
        user_id=user_id,
        type=AIJobType.PHOTO_ANALYSIS,
        status=AIJobStatus.PENDING,
        input_data={"image_base64": image_base64}
    )
    
    db.session.add(job)
    db.session.commit()

    # Dispatch Celery worker
    process_food_photo.apply_async(args=[job.id], task_id=job_id_uuid)

    return jsonify({"job_id": job.task_id, "status": job.status.value}), 202


@ai_bp.get("/photo/<task_id>/status")
@jwt_required()
def get_photo_status(task_id):
    """Polling endpoint to check if Gemini finished processing."""
    user_id = get_jwt_identity()
    job = AIJob.query.filter_by(task_id=task_id, user_id=user_id).first()
    
    if not job:
        return jsonify({"message": "Job not found"}), 404
        
    response = {
        "job_id": job.task_id,
        "status": job.status.value,
    }
    
    if job.status == AIJobStatus.DONE:
        response["result"] = job.result_data
    elif job.status == AIJobStatus.FAILED:
        response["error"] = job.error_message
        
    return jsonify(response), 200
