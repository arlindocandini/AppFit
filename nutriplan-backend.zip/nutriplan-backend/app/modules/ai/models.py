import enum
from ...extensions import db
from ...shared.models.base import BaseModel


class AIJobType(str, enum.Enum):
    PHOTO_ANALYSIS = "photo_analysis"


class AIJobStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    DONE = "done"
    FAILED = "failed"


class AIJob(BaseModel):
    __tablename__ = "ai_jobs"

    task_id = db.Column(db.String(100), unique=True, nullable=False, index=True)  # Celery task ID
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    type = db.Column(db.Enum(AIJobType), nullable=False, default=AIJobType.PHOTO_ANALYSIS)
    status = db.Column(db.Enum(AIJobStatus), nullable=False, default=AIJobStatus.PENDING)
    input_data = db.Column(db.JSON)   # e.g., image path or url
    result_data = db.Column(db.JSON)  # e.g., list of identified food items
    error_message = db.Column(db.Text)
    completed_at = db.Column(db.DateTime(timezone=True))

    # Relationships
    user = db.relationship("User", back_populates="ai_jobs")

    def __repr__(self):
        return f"<AIJob {self.task_id} {self.status}>"
