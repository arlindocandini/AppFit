import base64
import json
import logging
import google.generativeai as genai
from flask import current_app
from ...extensions import celery_app, db
from .models import AIJob, AIJobStatus

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, max_retries=3)
def process_food_photo(self, job_id: int):
    """
    Celery task that calls Gemini Vision API to analyze a food photo.
    `job_id` is the primary key of the AIJob in the database.
    """
    job = db.session.get(AIJob, job_id)
    if not job:
        logger.error(f"Job {job_id} not found in DB")
        return

    job.status = AIJobStatus.PROCESSING
    db.session.commit()

    try:
        # Get image data (assuming base64 string in input_data["image_base64"]) # TODO: handle actual Google Cloud Storage / S3 urls in prod
        image_data = job.input_data.get("image_base64")
        if not image_data:
            raise ValueError("No image data provided")

        api_key = current_app.config.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        
        # We use a generative model capable of vision
        model = genai.GenerativeModel("gemini-1.5-flash")

        prompt = """
        Analyze this food image. Provide a JSON response ONLY, with no markdown formatting.
        The JSON should have a key "items" which is a list of objects.
        Each object should have:
        - "name": string (name of the food in Portuguese)
        - "quantity_g": float (estimated weight in grams)
        - "calories": float (estimated total calories for that portion)
        - "confidence": string (HIGH, MEDIUM, LOW)
        """

        # decode base64
        import io
        from PIL import Image
        
        img_bytes = base64.b64decode(image_data)
        img = Image.open(io.BytesIO(img_bytes))

        response = model.generate_content([prompt, img])
        
        # Clean up response text to ensure it's valid JSON (often wraps in ```json ... ```)
        result_text = response.text.strip()
        if result_text.startswith("```json"):
            result_text = result_text[7:]
        if result_text.endswith("```"):
            result_text = result_text[:-3]

        parsed_result = json.loads(result_text)

        job.result_data = parsed_result
        job.status = AIJobStatus.DONE

    except Exception as e:
        logger.exception(f"Error processing AI job {job_id}: {e}")
        job.status = AIJobStatus.FAILED
        job.error_message = str(e)
        # Retry with exponential backoff (e.g. 60s, 120s, 240s)
        try:
            self.retry(countdown=60 * (2 ** self.request.retries))
        except celery_app.exceptions.MaxRetriesExceededError:
            pass  # status already set to FAILED

    finally:
        import datetime
        job.completed_at = datetime.datetime.now(datetime.timezone.utc)
        db.session.commit()

    return {"status": job.status.value}
